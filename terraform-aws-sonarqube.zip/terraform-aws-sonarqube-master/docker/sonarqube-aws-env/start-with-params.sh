#!/bin/bash
/usr/local/bin/aws-env exec ./start.sh