## examples/sonarqube-service
An example of using the sonarqube-service submodle