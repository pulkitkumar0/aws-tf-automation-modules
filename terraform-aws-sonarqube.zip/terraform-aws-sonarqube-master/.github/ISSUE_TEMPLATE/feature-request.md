---
name: 🚀 Feature Request
about: I have a suggestion!
---

### Feature request

> How can we improve the module?
