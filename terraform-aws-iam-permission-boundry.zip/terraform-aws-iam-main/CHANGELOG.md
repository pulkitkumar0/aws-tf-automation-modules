All notable changes to this terraform will be documented in this file.

## [1.0.1](https://github.com/BorisLabs/terraform-aws-iam/compare/v1.0.0...v1.0.1) (2021-03-13)


### Bug Fixes

* Release ([84c73de](https://github.com/BorisLabs/terraform-aws-iam/commit/84c73de65f99d1ad5656d7337d67cf720272e716))

# 1.0.0 (2021-03-10)


### Bug Fixes

* Added releaserc.json ([c66048e](https://github.com/BorisLabs/terraform-aws-iam/commit/c66048e59240752fe97e778afda1f982267cc37b))
* Include release map ([fe6997c](https://github.com/BorisLabs/terraform-aws-iam/commit/fe6997c892976bb294be0831282791fb5bcf1f7d))
* Issue with semantic version ([c1d8671](https://github.com/BorisLabs/terraform-aws-iam/commit/c1d867165e0697b08f7530592174e69032014f4e))
* Issue with semantic version ([775dcc4](https://github.com/BorisLabs/terraform-aws-iam/commit/775dcc44d8a5da91a1329ee1ed40d308aea97696))
* Issue with semantic version ([aa3ec08](https://github.com/BorisLabs/terraform-aws-iam/commit/aa3ec086efa1e4d83d6ee1295624654fdc46877e))
* Issue with semantic version ([0a9ca69](https://github.com/BorisLabs/terraform-aws-iam/commit/0a9ca69e6e84febfb3bed74506c03bd2e1409827))
