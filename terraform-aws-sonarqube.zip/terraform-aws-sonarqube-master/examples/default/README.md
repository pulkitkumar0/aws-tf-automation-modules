## examples/default

Basic example which creates a Sonarqube instance in the default VPC.
