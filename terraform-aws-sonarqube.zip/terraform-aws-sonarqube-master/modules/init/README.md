## Sonarqube Init
This submodule can be used to initialize the SSM key and rds username and password for use by the main module.