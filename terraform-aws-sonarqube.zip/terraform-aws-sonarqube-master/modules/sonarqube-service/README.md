## Sonarqube Service
This submodule creates a Sonarqube Service that can be deployed to different types of ECS Cluster