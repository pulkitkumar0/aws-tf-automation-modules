## v0.3.1 (Feb 20, 2020)

NOTES:

* Add .pre-commit-config.yaml to include terraform_fmt and terraform_docs
* Update README.md to be informative

## v0.3.0 (Apr 18, 2018)

NOTES:

* This module ***will not work*** on terraform-aws-provider version 1 anymore

ENHANCEMENTS:

* This module will work on terraform-aws-provider version 2. Thanks to [@michaa76](https://github.com/michaa76) on [#6](https://github.com/traveloka/terraform-aws-private-route53-zone/pull/6)

## v0.2.0 (Apr 17, 2018)

NOTES:

* Fix bad conventions

## v0.1.0 (Apr 5, 2018)

ENHANCEMENTS:

* Update README
* Add Example

* Fix tagging to follow convention

## v0.0.1 (Apr 4, 2018)

NOTES:
* Initial release
