# Changelog

## v0.3.2 - 2021-02-19
### Fixed
- Use `aws configure set region` instead of `AWS_DEFAULT_REGION` for subscription creation

## v0.3.1 - 2020-11-27
### Fixed
- Remove the need to specify a region since SMS is now available in Paris region

## v0.3.0 - 2020-06-26
### Changed
- Removed region provider block

## v0.2.0 - 2020-02-27
### Changed
- Better handling of subscriptions

## v0.1.0 - 2020-02-04
### Added
- Initial commit
